// Anda perlu mengirimkan data cartItems dan uang pembeli ke halaman ini
// Misalnya, menggunakan localStorage atau AJAX
// ...

// Anda perlu mengirimkan data cartItems dan uang pembeli ke halaman ini
// Misalnya, menggunakan localStorage atau AJAX
// ...

const cartItems = [];
const uangPembeli = [];
const transactions = JSON.parse(localStorage.getItem('transactions'));
const strukElement = document.getElementById("struks");
const date = new Date();

const currentDate = `${date.getDate()}/${date.getMonth()+1}/${date.getFullYear()}`; 

transactions.forEach(transaction => {
  if(currentDate === transaction.tanggal) {
    cartItems.push(transaction.cartItems);
    console.log(transaction.tanggal);
    strukElement.innerHTML += `
    <div class="struk-container">
      <div class="struk-header">
        <h2>Struk Belanja</h2>
        <p>${transaction.tanggal}</p> 
      </div>
      <ul id="struk-items"></ul>
      <p>Total Harga: Rp. <span id="struk-total">${transaction.totalPrice.toLocaleString('id', 'ID')}</span></p>
      <p>Uang Pembeli: Rp. <span id="struk-uang">${transaction.uangPembeli.toLocaleString('id', 'ID')}</span></p>
      <p>Kembalian: Rp. <span id="struk-kembalian">${transaction.uangKembalian.toLocaleString('id', 'ID')}</span></p>
    </div>`;
  
    const strukItems = document.querySelectorAll('#struk-items');
    strukItems.forEach(strukItem => {
      transaction.cartItems.forEach(cartItem => {
        strukItem.innerHTML += `
          <li>
            ${cartItem.nama} x ${cartItem.quantity} - Rp. ${cartItem.harga * cartItem.quantity}
          </li>
        `;
      })
    })
  }
});

console.log(JSON.parse(localStorage.getItem('transactions')));
console.log(cartItems);

document
  .getElementById("clear-struk")
  .addEventListener("click", function () {
    localStorage.clear();
  });