// Anda perlu mengirimkan data cartItems dan uang pembeli ke halaman ini
// Misalnya, menggunakan localStorage atau AJAX
// ...


// Anda perlu mengirimkan data cartItems dan uang pembeli ke halaman ini
// Misalnya, menggunakan localStorage atau AJAX
// ...


const cartItems = []; // Contoh mengambil data cartItems
const transactions = JSON.parse(localStorage.getItem('transactions')); // Contoh mengambil data uang pembeli
const uangPembeli = JSON.parse(localStorage.getItem('transactions'))[transactions.length-1].uangPembeli; // Contoh mengambil data uang pembeli
const totalPrice = JSON.parse(localStorage.getItem('transactions'))[transactions.length-1].totalPrice; // Contoh mengambil data uang pembeli

window.addEventListener("load", () => {
  const storedCartItems = localStorage.getItem('cartItems');
  if (storedCartItems) {
      cartItems = JSON.parse(storedCartItems);
      updateCart(); // Perbarui keranjang
  }
});

const tanggal = new Date();
const tanggalStruk = tanggal.toLocaleDateString('id-ID', {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
});

const strukElement = document.getElementById("struk");
strukElement.innerHTML = `
  <div class="struk-container">
    <h2>Struk Belanja</h2>
    <p>Teh Poci</p>
    <p>Tanggal: <span id="struk-tanggal">${tanggalStruk}</span></p> 
    <hr>
    <ul id="struk-items"></ul>
    <hr>
    <p>Total Harga: Rp. <span id="struk-total">${totalPrice.toLocaleString('id', 'ID')}</span></p>
    <p>Uang Pembeli: Rp. <span id="struk-uang">${uangPembeli.toLocaleString('id', 'ID')}</span></p>
    <p>Kembalian: Rp. <span id="struk-kembalian">${(uangPembeli-totalPrice).toLocaleString('id', 'ID')}</span></p>
  </div>
`;

const strukItems = strukElement.querySelector("#struk-items");
cartItems.forEach(item => {
  const listItem = document.createElement("li");
  listItem.textContent = `${item.nama} x ${item.quantity} - Rp. ${item.harga * item.quantity}`;
  strukItems.appendChild(listItem);
});

localStorage.removeItem('cartItems');