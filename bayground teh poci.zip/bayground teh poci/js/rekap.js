// Anda perlu mengirimkan data cartItems dan uang pembeli ke halaman ini
// Misalnya, menggunakan localStorage atau AJAX
// ...

// Anda perlu mengirimkan data cartItems dan uang pembeli ke halaman ini
// Misalnya, menggunakan localStorage atau AJAX
// ...

const cartItems = [];
const uangPembeli = [];
const transactions = JSON.parse(localStorage.getItem('transactions'));
const strukElement = document.getElementById("struks");

document
  .getElementById("clear-struk")
  .addEventListener("click", function () {
    localStorage.clear();
  });

transactions.forEach(transaction => {
  cartItems.push(transaction.cartItems);
  strukElement.innerHTML += `
    <div class="struk-container">
      <div class="struk-header">
        <h2>Struk Belanja</h2>
        <p>${transaction.tanggal}</p> 
      </div>
      <div class="struk-content">
        <h3>Items</h3>
        <ul id="struk-items"></ul>
      </div>
      <p>Total Harga: Rp. <span id="struk-total">${transaction.totalPrice.toLocaleString('id', 'ID')}</span></p>
      <p>Uang Pembeli: Rp. <span id="struk-uang">${transaction.uangPembeli.toLocaleString('id', 'ID')}</span></p>
      <p>Kembalian: Rp. <span id="struk-kembalian">${transaction.uangKembalian.toLocaleString('id', 'ID')}</span></p>
    </div>`;

  const strukItems = document.querySelectorAll('#struk-items');
  strukItems.forEach(strukItem => {
    transaction.cartItems.forEach(cartItem => {
      strukItem.innerHTML += `
        <li>
          <p>${cartItem.nama} x ${cartItem.quantity}</p>
          <p>Rp. ${cartItem.harga * cartItem.quantity}</p>
        </li>
      `;
    })
  })
});

console.log(JSON.parse(localStorage.getItem('transactions')));
console.log(cartItems);