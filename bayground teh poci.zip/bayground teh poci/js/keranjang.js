let cartItems = [];
// let cartItems = localStorage.getItem('cartItems');
let transactions = JSON.parse(localStorage.getItem('transactions')) || []; // Inisialisasi transactions

window.addEventListener("load", () => {
  const storedCartItems = localStorage.getItem('cartItems');
  if (storedCartItems) {
      cartItems = JSON.parse(storedCartItems);
      updateCart(); // Perbarui keranjang
  }
});


function updateCart() {
  const cartItemsList = document.getElementById("cart-items");
  cartItemsList.innerHTML = "";

  let totalPrice = 0;
  cartItems.forEach((item, index) => {
      const listItem = document.createElement("li");
      listItem.textContent = `${item.nama} x ${item.quantity} - Rp. ${item.harga * item.quantity}`;

      // Tambahkan tombol hapus
      const removeButton = document.createElement("button");
      removeButton.textContent = "Hapus";
      removeButton.classList.add("remove-button");
      removeButton.dataset.index = index; // Simpan index item
      removeButton.addEventListener("click", removeCartItem);
      listItem.appendChild(removeButton);

      cartItemsList.appendChild(listItem);

      totalPrice += item.harga * item.quantity;
  });

  document.getElementById("cart-total").textContent = totalPrice;
}

function removeCartItem(event) {
  const index = parseInt(event.target.dataset.index);
  cartItems.splice(index, 1); // Hapus item dari array

  // Simpan cartItems yang diperbarui ke localStorage
  localStorage.setItem('cartItems', JSON.stringify(cartItems));

  updateCart(); // Perbarui tampilan keranjang
}

function checkout() {
  if (cartItems.length === 0) {
      alert("Keranjang Belanja kosong!");
      return;
  }

  let totalPrice = 0;
  cartItems.forEach(item => {
      totalPrice += item.harga * item.quantity;
  });


  // Minta input uang pembeli
  const uangPembeli = prompt("Masukkan jumlah uang yang diberikan pembeli (Rp.):");

  // Validasi input uang pembeli
  if (uangPembeli === null || isNaN(uangPembeli) || uangPembeli <= 0) {
      alert("Input uang tidak valid. Silakan masukkan angka yang lebih besar dari 0.");
      return;
  }

  if (parseFloat(uangPembeli) < totalPrice) {
      alert("Uang pembeli tidak cukup! Pembayaran gagal.");
      return;
  }

  // Simpan data transaksi ke localStorage
  const today = new Date().toLocaleDateString('id-ID');
  transactions.push({
      tanggal: today,
      uangPembeli: parseFloat(uangPembeli),
      cartItems: cartItems,
      totalPrice: parseFloat(totalPrice),
      uangKembalian: (uangPembeli - totalPrice),
  });
  localStorage.setItem('transactions', JSON.stringify(transactions));

  window.location = 'sturk.html';

}

document.getElementById("checkout-button").addEventListener("click", checkout);
