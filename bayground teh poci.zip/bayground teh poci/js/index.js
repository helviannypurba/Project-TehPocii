const menuData = [
    {
        id: 1,
        nama: "Leci",
        harga: 13000,
        gambar: "assets/teh poci leci tea.jpg"
    },
    {
        id: 2,
        nama: "Kopi Alpukat",
        harga: 10000,
        gambar: "assets/kopi.jpg"
    },
    {
        id: 3,
        nama: "NS Jeruk Peras",
        harga: 10000,
        gambar: "assets/nutri.jpg"
    },
    {
        id: 4,
        nama: 'Mangga',
        harga: 10000,
        gambar: 'assets/teh poci mangga.jpg'
    },
    {
        id: 5,
        nama: 'Original',
        harga: 10000,
        gambar: 'assets/teh poci original.jpg'
    },
    {
        id: 6,
        nama: 'Anggur',
        harga: 10000,
        gambar: 'assets/teh poci anggur.jpg'
    },
    {
        id: 7,
        nama: 'Choco',
        harga: 10000,
        gambar: 'assets/choco.jpg'
    },
    {
        id: 8,
        nama: 'Lemon',
        harga: 10000,
        gambar: 'assets/teh poci lemon tea.jpg'
    },
    // ... (Data menu lainnya) ...
];

function addToCart(event) {
    const itemId = parseInt(event.target.dataset.id);
    const item = menuData.find(item => item.id === itemId);

    let cartItem = cartItems.find(item => item.id === itemId);
    if (cartItem) {
        cartItem.quantity++;
    } else {
        cartItem = { id: itemId, nama: item.nama, harga: item.harga, quantity: 1 };
        cartItems.push(cartItem);
    }

    // Simpan cartItems ke localStorage
    localStorage.setItem('cartItems', JSON.stringify(cartItems));

    // // Update jumlah item di keranjang
    // const cartCount = document.getElementById("cart-count");
    // cartCount.textContent = cartItems.length;

    // Tampilkan notifikasi
    const notification = document.getElementById("notification");
    notification.textContent = `${item.nama} ditambahkan ke keranjang!`;
    notification.style.display = "block";

    // Sembunyikan notifikasi setelah 2 detik
    setTimeout(() => {
        notification.style.display = "none";
    }, 2000);
}

function removeCartItem(event) {
    const index = parseInt(event.target.dataset.index);
    cartItems.splice(index, 1); // Hapus item dari array

    // Simpan cartItems yang diperbarui ke localStorage
    localStorage.setItem('cartItems', JSON.stringify(cartItems));

    updateCart(); // Perbarui tampilan keranjang
}

const menuItems = document.getElementById("menu-items");
let transactions = JSON.parse(localStorage.getItem('transactions')) || []; // Inisialisasi transactions
let cartItems = [];
menuItems.innerHTML = "";

menuData.forEach(item => {
    const menuItem = document.createElement("div");
    menuItem.classList.add("menu-item");
    menuItem.innerHTML = `
    <img src="${item.gambar}" alt="${item.nama}">
    <h3>${item.nama}</h3>
    <p>Rp. ${item.harga}</p>
    <button class="add-to-cart" data-id="${item.id}">Tambahkan</button>
    `;
    menuItems.appendChild(menuItem);
})

const addToCartButtons = document.querySelectorAll(".add-to-cart");
addToCartButtons.forEach(button => {
    button.addEventListener("click", addToCart);
});